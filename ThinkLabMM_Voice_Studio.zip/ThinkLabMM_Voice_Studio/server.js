import express from "express";
import helmet from "helmet";
import multer from "multer";
import dotenv from "dotenv";
import ffmpegPath from "ffmpeg-static";
import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { randomUUID } from "node:crypto";
import { fileURLToPath } from "node:url";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.GEMINI_API_KEY;
const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB || 1024);
const CHUNK_SECONDS = Number(process.env.AUDIO_CHUNK_SECONDS || 180);
const GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models";

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

const uploadDir = path.join(os.tmpdir(), "thinklabmm-uploads");
fs.mkdirSync(uploadDir, { recursive: true });
const upload = multer({
  dest: uploadDir,
  limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024 }
});

function requireKey(res) {
  if (!API_KEY) {
    res.status(503).json({
      error: "Gemini API Key မထည့်ရသေးပါ။ .env ဖိုင်ထဲတွင် GEMINI_API_KEY ထည့်ပါ။"
    });
    return false;
  }
  return true;
}

async function geminiGenerate(model, body) {
  const url = `${GEMINI_BASE}/${model}:generateContent?key=${encodeURIComponent(API_KEY)}`;
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = data?.error?.message || `Gemini API error (${response.status})`;
    throw new Error(message);
  }
  return data;
}

function pcmToWav(pcm, sampleRate = 24000, channels = 1, bitsPerSample = 16) {
  const header = Buffer.alloc(44);
  const byteRate = sampleRate * channels * bitsPerSample / 8;
  const blockAlign = channels * bitsPerSample / 8;
  header.write("RIFF", 0);
  header.writeUInt32LE(36 + pcm.length, 4);
  header.write("WAVE", 8);
  header.write("fmt ", 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(channels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(byteRate, 28);
  header.writeUInt16LE(blockAlign, 32);
  header.writeUInt16LE(bitsPerSample, 34);
  header.write("data", 36);
  header.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([header, pcm]);
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, apiKeyConfigured: Boolean(API_KEY) });
});

app.post("/api/tts", async (req, res) => {
  if (!requireKey(res)) return;
  try {
    const { text, voice = "Kore", style = "Speak naturally and clearly.", rate = 1 } = req.body || {};
    if (!text || typeof text !== "string" || !text.trim()) {
      return res.status(400).json({ error: "အသံဖန်တီးရန် စာသားထည့်ပါ။" });
    }
    if (text.length > 12000) {
      return res.status(413).json({ error: "စာသားအရှည်ဆုံး 12,000 characters အထိသာ လက်ခံပါတယ်။ အပိုင်းခွဲပါ။" });
    }

    const prompt = `${style} Read the following text in Burmese if it is Burmese. Keep pronunciation natural. Speaking rate preference: ${rate}. Text: ${text}`;
    const result = await geminiGenerate("gemini-2.5-flash-preview-tts", {
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } }
        }
      }
    });

    const part = result?.candidates?.[0]?.content?.parts?.find(p => p.inlineData?.data);
    if (!part) throw new Error("Gemini မှ Audio Data မရရှိပါ။");
    const mime = part.inlineData.mimeType || "audio/L16;rate=24000";
    const raw = Buffer.from(part.inlineData.data, "base64");
    const wav = mime.includes("wav") ? raw : pcmToWav(raw, 24000, 1, 16);
    res.setHeader("Content-Type", "audio/wav");
    res.setHeader("Content-Disposition", 'inline; filename="thinklabmm-voice.wav"');
    res.send(wav);
  } catch (err) {
    res.status(500).json({ error: err.message || "Voice generation မအောင်မြင်ပါ။" });
  }
});

function runFfmpeg(args) {
  return new Promise((resolve, reject) => {
    const child = spawn(ffmpegPath, args, { stdio: ["ignore", "ignore", "pipe"] });
    let errorText = "";
    child.stderr.on("data", chunk => { errorText += chunk.toString(); });
    child.on("error", reject);
    child.on("close", code => {
      if (code === 0) resolve();
      else reject(new Error(errorText.slice(-1800) || `FFmpeg exited with code ${code}`));
    });
  });
}

app.post("/api/recap", upload.single("video"), async (req, res) => {
  if (!requireKey(res)) {
    if (req.file?.path) fs.rmSync(req.file.path, { force: true });
    return;
  }
  if (!req.file) return res.status(400).json({ error: "Video ဖိုင်တစ်ခု ရွေးပေးပါ။" });

  const jobDir = path.join(os.tmpdir(), `thinklabmm-${randomUUID()}`);
  fs.mkdirSync(jobDir, { recursive: true });
  try {
    const audioPattern = path.join(jobDir, "chunk-%03d.wav");
    await runFfmpeg([
      "-y", "-i", req.file.path,
      "-vn", "-ac", "1", "-ar", "16000",
      "-f", "segment", "-segment_time", String(CHUNK_SECONDS),
      "-reset_timestamps", "1", "-c:a", "pcm_s16le", audioPattern
    ]);

    const chunks = fs.readdirSync(jobDir).filter(f => f.endsWith(".wav")).sort();
    if (!chunks.length) throw new Error("ဗီဒီယိုထဲမှ အသံကို မထုတ်ယူနိုင်ပါ။");

    const mode = req.body?.mode === "translate" ? "translate" : "recap";
    const targetLanguage = (req.body?.targetLanguage || "Burmese").slice(0, 40);
    const outputs = [];

    for (let i = 0; i < chunks.length; i++) {
      const audio = fs.readFileSync(path.join(jobDir, chunks[i]));
      const prompt = mode === "translate"
        ? `Listen to this audio segment and transcribe the spoken content accurately. Translate the meaning into ${targetLanguage}. Preserve speaker turns where possible. Do not invent missing words. This is segment ${i + 1} of ${chunks.length}.`
        : `Analyze this audio segment from a video. Write a clear, useful recap in ${targetLanguage}. Include the main events, key points, and important details. Do not invent information. This is segment ${i + 1} of ${chunks.length}.`;
      const result = await geminiGenerate("gemini-2.5-flash", {
        contents: [{
          parts: [
            { text: prompt },
            { inlineData: { mimeType: "audio/wav", data: audio.toString("base64") } }
          ]
        }]
      });
      const text = result?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("\n").trim();
      outputs.push(`--- အပိုင်း ${i + 1} ---\n${text || "စာသားမရရှိပါ။"}`);
    }

    const combined = outputs.join("\n\n");
    res.json({
      mode,
      chunkCount: chunks.length,
      text: mode === "recap"
        ? `VIDEO RECAP\n\n${combined}`
        : `TRANSCRIPTION / TRANSLATION\n\n${combined}`
    });
  } catch (err) {
    res.status(500).json({
      error: `Video Recap မအောင်မြင်ပါ။ ${err.message}`,
      note: "ဖိုင်အရွယ်အစား၊ Hosting upload limit၊ memory နှင့် Gemini API quota တို့ကြောင့် ကြီးမားသောဗီဒီယိုများကို အပိုင်းခွဲစမ်းသပ်ရန် လိုနိုင်ပါတယ်။"
    });
  } finally {
    if (req.file?.path) fs.rmSync(req.file.path, { force: true });
    fs.rmSync(jobDir, { recursive: true, force: true });
  }
});

app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError) {
    return res.status(413).json({ error: `Upload error: ${err.message}. Hosting upload limit ကို စစ်ဆေးပါ။` });
  }
  res.status(500).json({ error: err.message || "Server error" });
});

app.listen(PORT, () => {
  console.log(`ThinkLabMM Voice Studio running at http://localhost:${PORT}`);
});

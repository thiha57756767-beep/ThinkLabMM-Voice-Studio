# ThinkLabMM Voice Studio

Gemini API ကို အသုံးပြုတဲ့ Voice Generate နှင့် Video Recap / Translation starter app ဖြစ်ပါတယ်။

## ပါဝင်သော Feature များ

- Gemini 2.5 Flash Preview TTS ဖြင့် စာသားမှ အသံဖန်တီးခြင်း
- Voice profile ရွေးချယ်ခြင်း
- Audio preview နှင့် WAV download
- Video/audio upload
- FFmpeg ဖြင့် audio ကို 3-minute chunks ခွဲခြင်း
- Gemini 2.5 Flash ဖြင့် recap သို့မဟုတ် translation ထုတ်ပေးခြင်း
- API key ကို browser ထဲမထည့်ဘဲ server-side `.env` ထဲတွင်ထားခြင်း

## လိုအပ်ချက်

- Node.js 20 သို့မဟုတ် အထက်
- Gemini API key
- FFmpeg ကို `ffmpeg-static` package က ထည့်ပေးပါသည်

## စတင်အသုံးပြုရန်

1. ZIP ကို extract လုပ်ပါ။
2. Terminal / command line ဖွင့်ပြီး project folder ထဲဝင်ပါ။
3. Dependencies install လုပ်ပါ။

```bash
npm install
```

4. `.env.example` ကို `.env` ဟု copy/rename လုပ်ပါ။
5. `.env` ထဲတွင် ကိုယ့် Gemini API key ထည့်ပါ။

```env
GEMINI_API_KEY=your_real_api_key
PORT=3000
MAX_UPLOAD_MB=1024
AUDIO_CHUNK_SECONDS=180
```

6. App ကို run ပါ။

```bash
npm start
```

7. Browser မှ `http://localhost:3000` ကို ဖွင့်ပါ။

## လုံခြုံရေး

- API key ကို frontend HTML ထဲ မထည့်ပါနှင့်။
- `.env` ဖိုင်ကို အခြားသူများထံ မပို့ပါနှင့်။
- `.env` ကို Git repository ထဲ မတင်ပါနှင့်။
- Public deployment လုပ်မည်ဆိုလျှင် authentication, rate limiting, HTTPS နှင့် usage limits ထည့်သင့်ပါသည်။

## 2 နာရီဗီဒီယိုအတွက် အရေးကြီးသောကန့်သတ်ချက်များ

ဒီ package က browser ထဲမှာ ဗီဒီယိုတစ်ခုလုံးကို memory ထဲတင်မယ့်အစား server ပေါ်မှာ FFmpeg ဖြင့် အသံကို အပိုင်းခွဲပေးပါတယ်။ ဒါပေမဲ့ 2-hour video အလုပ်လုပ်မယ်လို့ hosting တိုင်းမှာ အာမမခံနိုင်ပါ။

အောက်ပါကန့်သတ်ချက်တွေကို စစ်ဆေးပါ။

- Hosting provider ရဲ့ maximum upload size
- Request timeout / execution timeout
- Server disk space နှင့် RAM
- Gemini API quota, payload size နှင့် rate limits
- တစ်ကြိမ်တည်း request အချိန်ကြာလွန်းခြင်း

ကြီးမားသောဗီဒီယိုများအတွက် background job queue နှင့် cloud object storage ပါသော deployment ကို အသုံးပြုရန် အကြံပြုပါသည်။ ယခု starter version တွင် chunk များကို တစ်ခုချင်းစီ စီမံသော်လည်း browser request တစ်ခုတည်းအတွင်း စောင့်ဆိုင်းရသောကြောင့် hosting timeout ဖြစ်နိုင်ပါသည်။

## Troubleshooting

- `Gemini API Key မထည့်ရသေးပါ`: `.env` ဖိုင်ရှိ/မရှိနှင့် key မှန်/မမှန် စစ်ပါ။
- `ffmpeg` error: Node dependencies ကို ပြန် install လုပ်ပါ။
- Upload error: `MAX_UPLOAD_MB` နှင့် hosting provider upload limit ကို စစ်ပါ။
- Gemini API error: API key, model availability, billing/quota နှင့် request limit စစ်ပါ။

## အသုံးပြုမှု

ဒီ project သည် စတင်အသုံးပြုနိုင်သော starter implementation ဖြစ်သည်။ Production အတွက် user authentication, per-user quotas, job status polling, cancellation, persistent storage နှင့် deployment-specific upload tuning ထပ်ထည့်သင့်ပါသည်။
